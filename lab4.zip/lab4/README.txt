I had a lot of difficulties with the garbage and delete methods. The garbage i managed to get working but it still has some flaws like printing out empty spaces ' ' due to my deletion process. My garbage method uses a Depth First Search (DFS) alrgorithm which is basically a stack that pushes in the states and its next states in so long as it reachable. In my delete methods i set them to empty spaces. I couldnt get the conditions right for just 'd' and 'd E'. So instead I made two methods of delete one for each scenario and had the char 'b' represent the one accompanied by a state. I have the same issue i did with the garbage method when deleting all of the states that are unreachable. Other than these methods, the rest work fine. 

References:

worked with aadil

Bro Code. (2021, October 6). C typedef 📛. YouTube. 
https://www.youtube.com/watch?v=CI9dRTvzgqE 

Depth first search (DFS) algorithm. Tutorialspoint. (n.d.). 
https://www.tutorialspoint.com/data_structures_algorithms/depth_first_traversal.htm 

Garry Explains. (2021, April 30). Understanding finite state machines (or finite-state automaton). YouTube. https://www.youtube.com/watch?v=2OiWs-h_M3A 

Gary Explains. (2021, May 6). How to implement a finite state machine in C. YouTube. 
https://www.youtube.com/watch?v=AR-y2Kw0THw 

Maw, R. (2016, April 6). Handling states with case statements. State machines in C. https://yakking.branchable.com/posts/state-machines-in-c/ 

Wang, I. (n.d.). coe 428 reference. GitHub. 
https://github.com/ivanw6/COE428/blob/main/lab4/simState.c 