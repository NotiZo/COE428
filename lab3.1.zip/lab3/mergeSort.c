#include "mySort.h"
void merge(int array[], int left, int middle, int right){
    int n1 = middle - left + 1; // size of left subarray
    int n2 = right - middle;    // size of right subarray

    // temporary arrays
    int L[n1], R[n2];

    // storing into temporary arrays
    for (int i = 0; i < n1; i++) {
        myCopy(&array[left + i], &L[i]);
    }
    for (int j = 0; j < n2; j++) {
        myCopy(&array[middle + 1 + j], &R[j]);
    }

    // merge temporary arrays into one
    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (myCompare(L[i], R[j]) <= 0) {
            myCopy(&L[i], &array[k]);
            i++;
        } else {
            myCopy(&R[j], &array[k]);
            j++;
        }
        k++;
    }

    // copy remaining elements of L[]
    while (i < n1) {
        myCopy(&L[i], &array[k]);
        i++;
        k++;
    }
    // copy remaining elements of R[]
    while (j < n2) {
        myCopy(&R[j], &array[k]);
        j++;
        k++;
    }
}
void mySort(int array[], unsigned int first, unsigned int last)
    {
        int middle;
        if(first<last){
            middle=(first+last)/2;

            //sort first&second halves
            mySort(array,first,middle);
            mySort(array,middle+1,last);

            //merge
            merge(array,first,middle,last);
        }
        
    }
