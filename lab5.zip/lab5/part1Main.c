#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
extern char *pop();
extern void push(int);
extern int isEmpty();

int main(int argc, char *argv[])
{
  int ch;
  char popped;
  while ((ch = getchar()) != EOF) {
    if (!(isalpha(ch) || ch == '>' || ch == '<' || ch == '/')){//if its any of > < / or is not an alphabetical character
      continue;
    }
    else if(ch=='<'){
      ch=getchar();
      
      if (isalpha(ch)){//if ch is a alphabet/letter, if it is then push it into the stack
        push(ch);
      }

      else if(ch=='/'){//if ch is '/' then pop from the stack
        ch=getchar();
        popped=pop();
        if (popped!=ch){//checks if the popped tag matches the previous
         fprintf(stderr, "Not valid, does not match the previous tag.");
         exit(1);
        }
        else if(isEmpty()){
          fprintf(stdout, "Valid.\n");
          exit(0);
        }
      }
    }
  }
  exit(0);
}