1st requirement: Works fine. When unproper tags are inputted it will not get pushed in. You put the tags first and will say valid once the stack is empty meaning its balanced. If the wrong exit tag is put, it will exit and ouput invalid.

2nd requirement: Works fine. Inputs are ended with a '0'. Descending uses delete and pushes it into the stack and prints out deleted. Ascending pops it out from the stack and prints it. Most methods are made in the intHeap class.

Question: To modify part1Main for stand-along tags, I would change or add an if statment to check if there is a '/' following the characters to identify a stand-alone tag. Once its identified, it can be ignored as it gets pushed and popped anyways, in otherwords it is already balanced.

References:
Worked with Aadil

Tutorialspoint. (n.d.). C library - . 
https://www.tutorialspoint.com/c_standard_library/ctype_h.htm 

Sambol, M. (2022a, June 9). Stacks in 3 minutes. YouTube. 
https://www.youtube.com/watch?v=KcT3aVgrrpU 

Sambol, M. (2022, July 7). Heaps in 6 minutes - methods. YouTube. 
https://www.youtube.com/watch?v=pAU21g-jBiE 