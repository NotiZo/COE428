#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
extern int pop();
extern void push(int);
extern int isEmpty();

extern void maxheapify(int);
extern int heapDelete();
extern void addHeap(int);
extern int heapSize();
extern void printTree(int);
extern void descend(int);
extern void ascend(int);


int main(int argc, char * argv[])
{
  int value;
  int numberofvalues=0;
  while (scanf("%d", &value) == 1 && value != 0) {
    fprintf(stderr, "READING INPUT: %d\n", value);
    addHeap(value);//adds value to the heap
    numberofvalues++;
  }

  //maxheapifying
  for (int i=(heapSize()-1)/2;i>=0;i--){//sets i to the middle
    maxheapify(i);
  }

  //printing out the tree
  printTree(0);//prints the tree
  printf("\n");

  //descending
  descend(numberofvalues);

  //Ascending
  ascend(numberofvalues);

  exit(0);
}
