#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
extern int pop();
extern void push(int);
/**
 *  The functions in this module implement a Heapdata structure
 *  of integers.
 */
static int size=0;
static int heap[100];

void swap(int i, int j)
{
  int temp = heap[i];
  heap[i] = heap[j];
  heap[j] = temp;
}

void maxheapify(int i){
  int l=2*i+1;
  int r=2*i+2;
  int templargest=i;

  if(l<size && heap[l]>heap[templargest]){//comparing value of left child with value of largest
    templargest=l;
  }
  if(r<size && heap[r]>heap[templargest]){//comparing value of right child with value of largest
    templargest=r;
  }
  if(templargest!=i){//if the largest is no longer value of i, then swap the largest with it
    swap(i,templargest);
    maxheapify(templargest);//recursive call at the new largest as i
  }
  
}
/**
 * heapDelete() removes the biggest integer in the heap and returns it.
 *
 */

int heapDelete()
{
  if(size==0){
    fprintf(stderr, "Heap underflow.");
    return -1;
  }
  int biggest=heap[0];
  heap[0]=heap[size-1];//-1 is needed cus 0 indice
  size--;//decrement
  maxheapify(0);
  return biggest;  //returns the biggest integer in the heap and removes it
}

/**
 *  addHeap(thing2add) adds the "thing2add" to the Heap.
 *
 */
void addHeap(int thing2add)
{
  if(size==100){
    fprintf(stderr, "Heap overflow.");
  }
  heap[size]=thing2add;
  size++;
}

/**
 * heapSize() returns the number of items in the Heap.
 *
 */
int heapSize()
{
  return size;  //A dummy return statement
}

void descend(int numberofvalues){
  printf("Descending:\n");
  for (int i=0;i<numberofvalues;i++){
    int deleted=heapDelete();
    push(deleted);
    fprintf(stderr,"%d\n",deleted);
  }
}

void ascend(int numberofvalues){
  printf("Ascending:\n");
  for (int i=0;i<numberofvalues;i++){
    fprintf(stderr,"%d\n",pop());
  }
}

void printTree(int value){
  int left=(2*value)+1;
	int right=(2*value)+2;

	printf("<node id=\"%d\">", heap[value]);
	if(left<size){
		printTree(left);
  }
	if(right<size){
		printTree(right);
  }
	printf("</node>");
}