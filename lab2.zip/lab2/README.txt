In this lab I modified the main function so that bugs like having the wrong amount of arguments and having the same from and destination would print out an statement showing an error. I also used if statements to assign the number of plates, from which tower and destination depending on the number of arguments inputed. 

Question 1:
1. the recursive call of towers(5,2,3) will be towers(4,2,1). In other words it solves the for 4 plates from tower 2 to 1 using tower 3.
2. there will be 5 recursive calls before it reaches the base case and returns imdiately solving for the plates in a backwards manner, starting at 1 plate then solving up to 5
3. the move that will be made is from tower 2 to 3 for the top/smallest plate
4. the second recursive call towers(3,2,3) as it is the next recursive line below the first recursive call towers(4,2,1)

Question 2:
there will be an output of 255 lines/moves

References:
worked with Aadil